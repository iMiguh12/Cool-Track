<?php
/*
Este es un archivo silencioso en busca de la NO-lectura de directorios :P! 

Si quieres borralo, o editalo, esto no afectará tus trackers. ;) 

*/
