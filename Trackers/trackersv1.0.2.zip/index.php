<?php
/**
* index.php | Archivo de Inicio
*
* Este archivo require todo, y presenta todos los datos y solicitudes por $_GET.
*
*
* @author Zerquix18
* @version 1.0.2
* @link http://zerquix18.com.ar/trackers-php/
* @category CLub Penguin
* @see trackers.php
* @package Trackers de Club Penguin
*
*
*/


define("ZER_TRACKERS", true);

require_once(	'./trackers.php'	);

/* Nada más que decir... */

?>